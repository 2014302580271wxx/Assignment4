package Asssignment4;

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class GUI extends JFrame {
	public JTextField tf;
	public JTextArea ta;
	public JButton bt;
	public JScrollPane sp;
	
	public GUI() {
		setLayout(new FlowLayout());
		tf=new JTextField(25);
		tf.setEditable(true);
		add("East",tf);
		
		ta=new JTextArea(20,25);
		ta.setEditable(false);
		add("South",ta);
		
		bt=new JButton("search");
		add("West",bt);
		
		//���ù�����
		sp=new JScrollPane(ta);
		add(sp);
		sp.setHorizontalScrollBarPolicy(JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		sp.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
	
	//�����ť�Ĺ��ܣ���ȡ�ؼ��֣����������㷨������������������
	bt.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			DataReader dr=new DataReader();
			TFCalculate cal=new TFCalculate();
			TFSort tfs=new TFSort();
			
			String s=tf.getText();
			dr.initialString();
			dr.getConnection(s);
			cal.allWords(s);
			cal.keyCount(s);
			cal.tf();
			
			String info1="";
			
			tfs.compareTF(s);
			
			for(int i=0;i<=dr.r;i++) {
				info1=info1+dr.info[i]+"\n";
			}
			
			ta.setText(info1);
			
		}
	}
	);
	
	}
}