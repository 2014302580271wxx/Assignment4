package Asssignment4;

import javax.swing.JFrame;

public class Main271 {
	
	public static void main(String[] args) {
		
		GUI gui=new GUI();
		gui.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		gui.setSize(550,500);
		gui.setVisible(true);
	}

}
