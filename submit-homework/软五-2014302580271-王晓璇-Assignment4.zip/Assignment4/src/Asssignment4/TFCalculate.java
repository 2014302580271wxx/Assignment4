package Asssignment4;

import java.util.StringTokenizer;
import java.util.regex.*;

public class TFCalculate {
	
	public int[] sumWords=new int[100];
	public int[] numKeyWords=new int[100];
	public double[] tf=new double[100];
	DataReader dr=new DataReader();
	
	
	public void allWords(String s) {
		//���еõ�info[]
		dr.getConnection(s);
		//ͳ��һ��������Ϣ���ܴ���
		for(int i=0;i<=dr.r;i++) {
			
			StringTokenizer st=new StringTokenizer(dr.info[i]);
			sumWords[i]=st.countTokens();
		}
	}
	
	//ͳ�ƽ�����Ϣ�йؼ��ʵ�����
	public void keyCount(String s) {
		dr.getConnection(s);
		for(int i=0;i<=dr.r;i++) {
			Pattern p=Pattern.compile(s);
			Matcher matcher=p.matcher(dr.info[i]);
			while(matcher.find()) {
				numKeyWords[i]=numKeyWords[i]+1;
			}
		}
	}
	
	//����tfֵ
	public void tf() {
		for(int i=0;i<=dr.r;i++) {
			tf[i]=numKeyWords[i]/sumWords[i];
		}
	}

}
