package Asssignment4;

public class TFSort {
	DataReader dr=new DataReader();
	TFCalculate tfc=new TFCalculate();
	
	public void compareTF(String s) {
		tfc.keyCount(s);
		tfc.allWords(s);
		tfc.tf();
		dr.initialString();
		dr.getConnection(s);
		for(int i=0;i<dr.r;i++) {
			for(int j=i+1;j<=dr.r;j++) {
			String l;
			double t;
			//����tfֵ��������
			if(tfc.tf[i]<tfc.tf[j]) {
				t=tfc.tf[i];
				tfc.tf[i]=tfc.tf[j];
				tfc.tf[j]=t;
				
				l=dr.info[i];
				dr.info[i]=dr.info[j];
				dr.info[j]=l;
			}
			}
		}
	}
}
